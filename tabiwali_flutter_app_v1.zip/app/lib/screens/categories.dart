import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'category_products.dart';
import 'search.dart';

class CategoriesScreen extends StatefulWidget {
  const CategoriesScreen({super.key});
  @override
  State<CategoriesScreen> createState() => _CategoriesScreenState();
}

class _CategoriesScreenState extends State<CategoriesScreen> {
  int _sel = 0;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final tree = s.tree;
    if (tree.isEmpty) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (_sel >= tree.length) _sel = 0;
    final cur = tree[_sel];
    return Scaffold(
      appBar: AppBar(
        title: const Text('ক্যাটাগরি', style: TextStyle(fontSize: 18)),
        actions: [
          IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SearchScreen())), icon: const Icon(Icons.search)),
        ],
      ),
      body: Row(children: [
        Container(
          width: 98,
          color: const Color(0xFFF3F3F3),
          child: ListView.builder(
            itemCount: tree.length,
            itemBuilder: (c, i) {
              final n = tree[i];
              final on = i == _sel;
              return InkWell(
                onTap: () => setState(() => _sel = i),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
                  decoration: BoxDecoration(color: on ? Colors.white : null, border: Border(left: BorderSide(color: on ? orangeBtn : Colors.transparent, width: 4))),
                  child: Column(children: [
                    Text(n.icon, style: const TextStyle(fontSize: 22)),
                    const SizedBox(height: 3),
                    Text(n.label, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, fontWeight: on ? FontWeight.w700 : FontWeight.w400)),
                  ]),
                ),
              );
            },
          ),
        ),
        Expanded(
          child: Container(
            color: Colors.white,
            child: ListView(padding: const EdgeInsets.all(12), children: [
              InkWell(
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryProductsScreen(node: cur))),
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: const Color(0xFFFFF4DD), borderRadius: BorderRadius.circular(10)),
                  child: Row(children: [
                    Expanded(child: Text('${cur.label} — সব পণ্য', style: const TextStyle(fontWeight: FontWeight.w700))),
                    const Icon(Icons.chevron_right),
                  ]),
                ),
              ),
              const SizedBox(height: 12),
              for (final sub in cur.children) ...[
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: InkWell(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryProductsScreen(node: sub))),
                    child: Text(sub.name, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14.5)),
                  ),
                ),
                if (sub.children.isNotEmpty)
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    for (final leaf in sub.children)
                      ActionChip(
                        label: Text(leaf.name, style: const TextStyle(fontSize: 12.5)),
                        backgroundColor: const Color(0xFFF1F4F8),
                        side: BorderSide.none,
                        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryProductsScreen(node: leaf))),
                      ),
                  ]),
                const SizedBox(height: 14),
              ],
            ]),
          ),
        ),
      ]),
    );
  }
}
