import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../api.dart';
import '../models.dart';
import '../state.dart';
import '../widgets.dart';

class WishlistScreen extends StatefulWidget {
  const WishlistScreen({super.key});
  @override
  State<WishlistScreen> createState() => _WishlistScreenState();
}

class _WishlistScreenState extends State<WishlistScreen> {
  List<Product> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final ids = context.read<AppState>().wish.toList();
      final r = await Api.productsByIds(ids);
      if (mounted) setState(() => _items = r);
    } catch (_) {}
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final wish = context.watch<AppState>().wish;
    final shown = _items.where((p) => wish.contains(p.id)).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('পছন্দের তালিকা', style: TextStyle(fontSize: 18))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : shown.isEmpty
              ? const Center(child: Text('পছন্দের তালিকা খালি', style: TextStyle(color: Colors.black54)))
              : ListView.separated(itemCount: shown.length, separatorBuilder: (_, __) => const Divider(height: 1), itemBuilder: (c, i) => ProductRow(shown[i])),
    );
  }
}
