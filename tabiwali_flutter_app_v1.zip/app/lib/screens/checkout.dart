import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../api.dart';
import '../config.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'orders.dart';

class CheckoutScreen extends StatefulWidget {
  final List<CartItem> items;
  final bool fromCart;
  const CheckoutScreen({super.key, required this.items, required this.fromCart});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _addr = TextEditingController();
  final _note = TextEditingController();
  final _sender = TextEditingController();
  final _txn = TextEditingController();
  String _zone = 'in'; // in | out
  String _pay = 'COD';
  bool _busy = false;
  // one id per checkout so a retry after a network failure never creates a duplicate order
  late final String _orderId = 'ORD${DateTime.now().millisecondsSinceEpoch.toRadixString(36).toUpperCase()}${_rand()}';

  static String _rand() {
    const ch = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    final r = Random();
    return List.generate(3, (_) => ch[r.nextInt(ch.length)]).join();
  }

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>();
    _name.text = s.profile['name'] ?? '';
    _phone.text = s.profile['phone'] ?? '';
    _addr.text = s.profile['address'] ?? '';
  }

  @override
  void dispose() {
    for (final c in [_name, _phone, _addr, _note, _sender, _txn]) {
      c.dispose();
    }
    super.dispose();
  }

  num get _total => widget.items.fold<num>(0, (a, c) => a + c.line);

  Future<void> _place() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    final s = context.read<AppState>();
    final u = Supabase.instance.client.auth.currentUser;
    final addressFull = '[${_zone == 'in' ? 'ঢাকা সিটির ভিতরে' : 'ঢাকা সিটির বাইরে'}] ${_addr.text.trim()}';
    final customer = {
      'name': _name.text.trim(),
      'phone': _phone.text.trim(),
      'address': addressFull,
      'email': u?.email ?? '',
      'uid': u?.id,
    };
    final payment = {'method': _pay, 'sender': _pay == 'bKash' || _pay == 'Nagad' ? _sender.text.trim() : '', 'txn': _pay == 'bKash' || _pay == 'Nagad' ? _txn.text.trim() : ''};
    try {
      await Api.placeOrder(id: _orderId, customer: customer, payment: payment, message: _note.text.trim(), items: widget.items);
    } catch (e) {
      if (mounted) {
        setState(() => _busy = false);
        snack(context, 'অর্ডার পাঠানো যায়নি — ইন্টারনেট দেখে আবার চেষ্টা করুন', error: true);
      }
      return;
    }
    final order = AppOrder(
      id: _orderId,
      createdAt: DateTime.now().toIso8601String(),
      total: _total,
      payment: _pay,
      name: customer['name'] as String,
      phone: customer['phone'] as String,
      address: addressFull,
      items: widget.items.map((c) => OrderLine(c.p.id, c.p.name, c.p.price, c.qty, c.size)).toList(),
    );
    s.addOrder(order);
    if (widget.fromCart) s.clearCart();
    String? payUrl;
    if (_pay == 'Online') {
      try {
        payUrl = await Api.startOnlinePayment(orderId: _orderId, total: _total, customer: customer, productNames: widget.items.map((c) => c.p.name).join(', '));
      } catch (_) {
        if (mounted) snack(context, 'অনলাইন পেমেন্ট চালু করা যায়নি। অর্ডার জমা হয়েছে — অন্য পদ্ধতিতে পেমেন্ট করুন।', error: true);
      }
    }
    if (!mounted) return;
    setState(() => _busy = false);
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => OrderDoneScreen(order: order)));
    if (payUrl != null) openUrl(payUrl);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('চেকআউট', style: TextStyle(fontSize: 18))),
      body: Form(
        key: _form,
        child: ListView(padding: const EdgeInsets.all(12), children: [
          _card('ডেলিভারি ঠিকানা', [
            TextFormField(controller: _name, decoration: const InputDecoration(labelText: 'পুরো নাম'), validator: (v) => (v ?? '').trim().length < 2 ? 'নাম লিখুন' : null),
            const SizedBox(height: 10),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'মোবাইল নম্বর (01XXXXXXXXX)'),
              validator: (v) => RegExp(r'^01[3-9]\d{8}$').hasMatch((v ?? '').trim()) ? null : 'সঠিক ১১ ডিজিটের নম্বর দিন',
            ),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _zoneBtn('in', 'ঢাকা সিটির ভিতরে')),
              const SizedBox(width: 8),
              Expanded(child: _zoneBtn('out', 'ঢাকা সিটির বাইরে')),
            ]),
            const SizedBox(height: 10),
            TextFormField(controller: _addr, maxLines: 3, decoration: const InputDecoration(labelText: 'পূর্ণ ঠিকানা (এলাকা, থানা, জেলা)'), validator: (v) => (v ?? '').trim().length < 8 ? 'পূর্ণ ঠিকানা লিখুন' : null),
            const SizedBox(height: 10),
            TextFormField(controller: _note, decoration: const InputDecoration(labelText: 'বিক্রেতার জন্য নোট (ঐচ্ছিক)')),
          ]),
          _card('পেমেন্ট পদ্ধতি', [
            _payTile('COD', '💵 ক্যাশ অন ডেলিভারি', 'পণ্য হাতে পেয়ে টাকা দিন'),
            _payTile('bKash', '📱 বিকাশ', 'Send Money: ${Cfg.bkash}'),
            _payTile('Nagad', '📱 নগদ', 'Send Money: ${Cfg.nagad}'),
            _payTile('Online', '💳 অনলাইন পেমেন্ট', 'কার্ড / মোবাইল ব্যাংকিং (SSLCommerz)'),
            if (_pay == 'bKash' || _pay == 'Nagad') ...[
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: Text('${taka(_total)} পাঠান: ${_pay == 'bKash' ? Cfg.bkash : Cfg.nagad}', style: const TextStyle(fontSize: 13))),
                IconButton(
                  onPressed: () {
                    Clipboard.setData(const ClipboardData(text: '01856417790'));
                    snack(context, 'নম্বর কপি হয়েছে');
                  },
                  icon: const Icon(Icons.copy, size: 18),
                ),
              ]),
              TextFormField(controller: _sender, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'যে নম্বর থেকে পাঠিয়েছেন'), validator: (v) => (v ?? '').trim().length < 11 ? 'প্রেরকের নম্বর দিন' : null),
              const SizedBox(height: 10),
              TextFormField(controller: _txn, decoration: const InputDecoration(labelText: 'ট্রানজেকশন আইডি (TrxID)'), validator: (v) => (v ?? '').trim().length < 6 ? 'TrxID দিন' : null),
            ],
          ]),
          _card('অর্ডার সারাংশ', [
            for (final c in widget.items)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(children: [
                  SizedBox(width: 44, height: 44, child: ClipRRect(borderRadius: BorderRadius.circular(6), child: ProductPic(c.p))),
                  const SizedBox(width: 10),
                  Expanded(child: Text('${c.p.name}${c.size != null ? ' (${c.size})' : ''}  × ${c.qty}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13))),
                  Text(taka(c.line), style: const TextStyle(fontWeight: FontWeight.w600)),
                ]),
              ),
            const Divider(),
            Row(children: [const Expanded(child: Text('পণ্যের মোট দাম', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))), Text(taka(_total), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: priceRed))]),
            const SizedBox(height: 4),
            Text(
              'ডেলিভারি চার্জ (${_zone == 'in' ? 'ঢাকা সিটির ভিতরে' : 'ঢাকা সিটির বাইরে'}) পণ্যভেদে আলাদা — ডিফল্ট ${taka(_zone == 'in' ? Cfg.defaultDlvIn : Cfg.defaultDlvOut)}। বিক্রেতা অর্ডার কনফার্মের সময় জানাবেন।',
              style: const TextStyle(fontSize: 12, color: Colors.black54),
            ),
          ]),
          const SizedBox(height: 6),
          ElevatedButton(
            onPressed: _busy ? null : _place,
            style: pillButton(yellowBtn),
            child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5)) : Text('অর্ডার নিশ্চিত করুন · ${taka(_total)}'),
          ),
          const SizedBox(height: 24),
        ]),
      ),
    );
  }

  Widget _card(String title, List<Widget> kids) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          ...kids,
        ]),
      );

  Widget _zoneBtn(String v, String label) => InkWell(
        onTap: () => setState(() => _zone = v),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 11),
          alignment: Alignment.center,
          decoration: BoxDecoration(color: _zone == v ? const Color(0xFFFFF4DD) : Colors.white, border: Border.all(color: _zone == v ? orangeBtn : const Color(0xFFCCCCCC), width: _zone == v ? 2 : 1), borderRadius: BorderRadius.circular(8)),
          child: Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
        ),
      );

  Widget _payTile(String v, String title, String sub) => RadioListTile<String>(
        value: v,
        groupValue: _pay,
        onChanged: (x) => setState(() => _pay = x!),
        dense: true,
        contentPadding: EdgeInsets.zero,
        activeColor: navy,
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(sub, style: const TextStyle(fontSize: 12)),
      );
}
