import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../api.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _ctl = TextEditingController();
  final _sc = ScrollController();
  final List<Product> _items = [];
  String _q = '';
  String _sort = 'new';
  int _page = 0;
  bool _loading = false, _more = true, _searched = false, _error = false;

  @override
  void initState() {
    super.initState();
    _sc.addListener(() {
      if (_searched && _sc.position.pixels > _sc.position.maxScrollExtent - 500) _run();
    });
  }

  @override
  void dispose() {
    _ctl.dispose();
    _sc.dispose();
    super.dispose();
  }

  void _submit(String q) {
    q = q.trim();
    if (q.isEmpty) return;
    FocusScope.of(context).unfocus();
    context.read<AppState>().addHistory(q);
    _q = q;
    _ctl.text = q;
    _run(reset: true);
  }

  Future<void> _run({bool reset = false}) async {
    if (_loading || (!_more && !reset)) return;
    setState(() {
      _loading = true;
      _searched = true;
      _error = false;
      if (reset) {
        _page = 0;
        _more = true;
        _items.clear();
      }
    });
    try {
      final r = await Api.products(q: _q, page: _page, size: 20, sort: _sort);
      if (!mounted) return;
      setState(() {
        _items.addAll(r);
        _more = r.length == 20;
        _page++;
      });
    } catch (_) {
      if (mounted) setState(() => _error = true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _pickSort() {
    showModalBottomSheet(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final e in const {'new': 'নতুন আগে', 'popular': 'জনপ্রিয়', 'low': 'দাম: কম থেকে বেশি', 'high': 'দাম: বেশি থেকে কম'}.entries)
            ListTile(
              title: Text(e.value),
              trailing: _sort == e.key ? const Icon(Icons.check, color: okGreen) : null,
              onTap: () {
                Navigator.pop(c);
                setState(() => _sort = e.key);
                if (_q.isNotEmpty) _run(reset: true);
              },
            ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Container(
          height: 42,
          margin: const EdgeInsets.only(right: 12),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)),
          child: Row(children: [
            Expanded(
              child: TextField(
                controller: _ctl,
                autofocus: true,
                textInputAction: TextInputAction.search,
                onSubmitted: _submit,
                style: const TextStyle(color: Colors.black87, fontSize: 15),
                decoration: const InputDecoration(hintText: 'পণ্য খুঁজুন…', border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none, filled: false),
              ),
            ),
            InkWell(
              onTap: () => _submit(_ctl.text),
              child: Container(
                width: 46,
                height: 42,
                decoration: const BoxDecoration(color: searchBtn, borderRadius: BorderRadius.horizontal(right: Radius.circular(8))),
                child: const Icon(Icons.search, color: Colors.black87),
              ),
            ),
          ]),
        ),
      ),
      body: !_searched
          ? ListView(children: [
              if (s.history.isNotEmpty)
                Container(
                  color: Colors.white,
                  child: Column(children: [
                    ListTile(
                      title: const Text('সাম্প্রতিক খোঁজ', style: TextStyle(fontWeight: FontWeight.w700)),
                      trailing: TextButton(onPressed: s.clearHistory, child: const Text('মুছুন')),
                    ),
                    for (final h in s.history) ListTile(dense: true, leading: const Icon(Icons.history, size: 20), title: Text(h), onTap: () => _submit(h)),
                  ]),
                ),
            ])
          : Column(children: [
              Container(
                color: Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(children: [
                  Text(_loading && _items.isEmpty ? 'খোঁজা হচ্ছে…' : '${_items.length}${_more ? '+' : ''} ফলাফল', style: const TextStyle(color: Colors.black54)),
                  const Spacer(),
                  TextButton.icon(onPressed: _pickSort, icon: const Icon(Icons.sort, size: 18), label: const Text('সর্ট')),
                ]),
              ),
              Expanded(
                child: _items.isEmpty && !_loading
                    ? Center(child: Text(_error ? 'ইন্টারনেট সংযোগ পরীক্ষা করুন' : '"$_q" এর জন্য কিছু পাওয়া যায়নি', style: const TextStyle(color: Colors.black54)))
                    : ListView.separated(
                        controller: _sc,
                        itemCount: _items.length + (_loading ? 1 : 0),
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (c, i) => i < _items.length ? ProductRow(_items[i]) : const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator(strokeWidth: 2.5))),
                      ),
              ),
            ]),
    );
  }
}
