import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import '../config.dart';

String statusBn(String s) {
  switch (s.toLowerCase()) {
    case 'pending':
      return 'অপেক্ষমান';
    case 'confirmed':
      return 'কনফার্মড';
    case 'processing':
      return 'প্রসেসিং';
    case 'shipped':
      return 'শিপড';
    case 'delivered':
      return 'ডেলিভারড';
    case 'cancelled':
    case 'canceled':
      return 'বাতিল';
    default:
      return s;
  }
}

Color statusColor(String s) {
  switch (s.toLowerCase()) {
    case 'delivered':
      return okGreen;
    case 'cancelled':
    case 'canceled':
      return dealRed;
    case 'pending':
      return const Color(0xFFB26B00);
    default:
      return linkBlue;
  }
}

String _date(String iso) => iso.length >= 10 ? iso.substring(0, 10) : iso;

class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});
  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  @override
  void initState() {
    super.initState();
    context.read<AppState>().refreshOrders();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('আমার অর্ডার', style: TextStyle(fontSize: 18))),
      body: s.orders.isEmpty
          ? const Center(child: Text('এখনো কোনো অর্ডার করেননি', style: TextStyle(color: Colors.black54)))
          : RefreshIndicator(
              onRefresh: s.refreshOrders,
              child: ListView.builder(
                padding: const EdgeInsets.all(10),
                itemCount: s.orders.length,
                itemBuilder: (c, i) {
                  final o = s.orders[i];
                  return InkWell(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => OrderDetailScreen(order: o))),
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Expanded(child: Text('#${o.id}', style: const TextStyle(fontWeight: FontWeight.w700))),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                            decoration: BoxDecoration(color: statusColor(o.status).withOpacity(.12), borderRadius: BorderRadius.circular(20)),
                            child: Text(statusBn(o.status), style: TextStyle(color: statusColor(o.status), fontSize: 12, fontWeight: FontWeight.w700)),
                          ),
                        ]),
                        const SizedBox(height: 4),
                        Text('${_date(o.createdAt)} · ${o.items.length} আইটেম · ${taka(o.total)}', style: const TextStyle(color: Colors.black54, fontSize: 13)),
                        const SizedBox(height: 6),
                        Text(o.items.map((e) => e.name).join(', '), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                      ]),
                    ),
                  );
                },
              ),
            ),
    );
  }
}

class OrderDetailScreen extends StatelessWidget {
  final AppOrder order;
  const OrderDetailScreen({super.key, required this.order});
  @override
  Widget build(BuildContext context) {
    final o = order;
    const steps = ['pending', 'confirmed', 'shipped', 'delivered'];
    var idx = steps.indexOf(o.status.toLowerCase());
    if (idx < 0) idx = o.status.toLowerCase() == 'processing' ? 1 : 0;
    return Scaffold(
      appBar: AppBar(title: Text('অর্ডার #${o.id}', style: const TextStyle(fontSize: 16))),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('অর্ডারের অবস্থা', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 12),
            Row(children: [
              for (var i = 0; i < steps.length; i++) ...[
                Expanded(
                  child: Column(children: [
                    Icon(i <= idx ? Icons.check_circle : Icons.radio_button_unchecked, color: i <= idx ? okGreen : Colors.black26),
                    const SizedBox(height: 4),
                    Text(statusBn(steps[i]), style: TextStyle(fontSize: 11, color: i <= idx ? Colors.black87 : Colors.black45)),
                  ]),
                ),
              ],
            ]),
            if (o.track.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text('ট্র্যাকিং: ${o.track}${o.courier.isNotEmpty ? ' · কুরিয়ার: ${o.courier}' : ''}', style: const TextStyle(fontSize: 13))),
          ]),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('পণ্যসমূহ', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 8),
            for (final it in o.items)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(children: [
                  Expanded(child: Text('${it.name}${it.size != null ? ' (${it.size})' : ''} × ${it.qty}', style: const TextStyle(fontSize: 13.5))),
                  Text(taka(it.price * it.qty), style: const TextStyle(fontWeight: FontWeight.w600)),
                ]),
              ),
            const Divider(),
            Row(children: [const Expanded(child: Text('মোট', style: TextStyle(fontWeight: FontWeight.w700))), Text(taka(o.total), style: const TextStyle(fontWeight: FontWeight.w700, color: priceRed))]),
          ]),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('ডেলিভারি ও পেমেন্ট', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 8),
            Text('${o.name} · ${o.phone}'),
            const SizedBox(height: 2),
            Text(o.address, style: const TextStyle(color: Colors.black87)),
            const SizedBox(height: 6),
            Text('পেমেন্ট: ${o.payment}'),
          ]),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: () => openUrl('https://wa.me/${Cfg.whatsapp}?text=${Uri.encodeComponent('আমার অর্ডার #${o.id} সম্পর্কে জানতে চাই')}'),
          icon: const Icon(Icons.chat_outlined),
          label: const Text('অর্ডার নিয়ে সাহায্য'),
          style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(44), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
        ),
      ]),
    );
  }
}

class OrderDoneScreen extends StatelessWidget {
  final AppOrder order;
  const OrderDoneScreen({super.key, required this.order});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.check_circle, color: okGreen, size: 90),
            const SizedBox(height: 14),
            const Text('অর্ডার জমা হয়েছে!', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text('অর্ডার নম্বর: #${order.id}', style: const TextStyle(fontSize: 16)),
            Text('মোট: ${taka(order.total)}', style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 6),
            const Text('বিক্রেতা শীঘ্রই কনফার্ম করবেন।', style: TextStyle(color: Colors.black54)),
            const SizedBox(height: 28),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => OrderDetailScreen(order: order))),
              style: pillButton(yellowBtn),
              child: const Text('অর্ডার ট্র্যাক করুন'),
            ),
            const SizedBox(height: 10),
            OutlinedButton(
              onPressed: () {
                context.read<AppState>().setTab(0);
                Navigator.of(context).popUntil((r) => r.isFirst);
              },
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
              child: const Text('কেনাকাটা চালিয়ে যান'),
            ),
          ]),
        ),
      ),
    );
  }
}
