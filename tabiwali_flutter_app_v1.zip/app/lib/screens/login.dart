import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config.dart';
import '../theme.dart';
import '../widgets.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _busy = false, _hide = true;

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final e = _email.text.trim();
    if (!e.contains('@') || _pass.text.isEmpty) {
      snack(context, 'ইমেইল ও পাসওয়ার্ড দিন', error: true);
      return;
    }
    setState(() => _busy = true);
    try {
      await Supabase.instance.client.auth.signInWithPassword(email: e, password: _pass.text);
      if (mounted) Navigator.of(context).pop();
    } on AuthException catch (ex) {
      final m = ex.message.toLowerCase();
      if (mounted) snack(context, m.contains('invalid') ? 'ইমেইল বা পাসওয়ার্ড ভুল' : (m.contains('confirm') ? 'আগে ইমেইল ভেরিফাই করুন' : 'লগইন হয়নি: ${ex.message}'), error: true);
    } catch (_) {
      if (mounted) snack(context, 'ইন্টারনেট সংযোগ পরীক্ষা করুন', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(title: const Text('লগইন', style: TextStyle(fontSize: 18))),
      body: ListView(padding: const EdgeInsets.all(22), children: [
        Center(child: ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.asset('assets/logo.png', width: 80, height: 80))),
        const SizedBox(height: 14),
        const Center(child: Text('Tabiwali-তে স্বাগতম', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700))),
        const SizedBox(height: 22),
        TextField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'ইমেইল')),
        const SizedBox(height: 12),
        TextField(
          controller: _pass,
          obscureText: _hide,
          decoration: InputDecoration(labelText: 'পাসওয়ার্ড', suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => _hide = !_hide))),
        ),
        const SizedBox(height: 18),
        ElevatedButton(onPressed: _busy ? null : _login, style: pillButton(yellowBtn), child: _busy ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.5)) : const Text('লগইন')),
        const SizedBox(height: 8),
        TextButton(onPressed: () => openUrl(Cfg.siteUrl), child: const Text('পাসওয়ার্ড ভুলে গেছেন? ওয়েবসাইটে রিসেট করুন')),
        const Divider(height: 30),
        OutlinedButton(
          onPressed: () => openUrl(Cfg.siteUrl),
          style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(46), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
          child: const Text('নতুন অ্যাকাউন্ট খুলুন (ওয়েবসাইটে)'),
        ),
        const SizedBox(height: 8),
        const Text('লগইন ছাড়াই অর্ডার করা যায়। লগইন করলে আপনার তথ্য অটো-ফিল হবে।', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
      ]),
    );
  }
}
