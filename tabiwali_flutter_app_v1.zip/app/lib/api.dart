import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'models.dart';

class Api {
  static SupabaseClient get sb => Supabase.instance.client;

  static const _base = 'id,seller_id,name,cat,price,old_price,emoji,bg,tag,stock,sold,sizes,has_video,created_at';
  // Same fallback order the website uses, because some columns only exist after an SQL migration.
  static const _colSets = [
    '$_base,brand,thumb_url,thumb_b64',
    '$_base,brand,thumb_b64',
    '$_base,thumb_b64',
    _base,
  ];
  static int _colIdx = 0;

  /// sort: new | low | high | popular
  static Future<List<Product>> products({
    List<String>? cats,
    String? q,
    int page = 0,
    int size = 20,
    bool dealsOnly = false,
    String sort = 'new',
  }) async {
    Object? lastErr;
    for (var i = _colIdx; i < _colSets.length; i++) {
      try {
        var f = sb.from('products').select(_colSets[i]);
        if (cats != null && cats.isNotEmpty) f = f.inFilter('cat', cats);
        if (q != null && q.trim().isNotEmpty) f = f.ilike('name', '%${q.trim()}%');
        if (dealsOnly) f = f.not('old_price', 'is', null);
        String col = 'created_at';
        bool asc = false;
        if (sort == 'low') {
          col = 'price';
          asc = true;
        } else if (sort == 'high') {
          col = 'price';
        } else if (sort == 'popular') {
          col = 'sold';
        }
        final res = await f.order(col, ascending: asc).range(page * size, page * size + size - 1);
        _colIdx = i;
        return (res as List).whereType<Map>().map(Product.fromMap).toList();
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr ?? Exception('products failed');
  }

  static Future<List<Product>> productsByIds(List<int> ids) async {
    if (ids.isEmpty) return [];
    Object? lastErr;
    for (var i = _colIdx; i < _colSets.length; i++) {
      try {
        final res = await sb.from('products').select(_colSets[i]).inFilter('id', ids);
        _colIdx = i;
        return (res as List).whereType<Map>().map(Product.fromMap).toList();
      } catch (e) {
        lastErr = e;
      }
    }
    throw lastErr ?? Exception('products failed');
  }

  static Future<void> loadDetail(Product p) async {
    if (p.detailLoaded) return;
    for (final cols in ['description,image_b64,images,delivery_dhaka,delivery_outside', 'description,image_b64,images']) {
      try {
        final m = await sb.from('products').select(cols).eq('id', p.id).maybeSingle();
        if (m != null) {
          final d = Product.fromMap(m);
          p.description = d.description;
          p.imageB64 = d.imageB64;
          p.images = d.images;
          p.dlvIn = d.dlvIn;
          p.dlvOut = d.dlvOut;
        }
        p.detailLoaded = true;
        return;
      } catch (_) {}
    }
  }

  static Future<Map<int, Rating>> ratings() async {
    try {
      final res = await sb.from('product_rating_summary').select('product_id,avg_rating,review_count');
      final out = <int, Rating>{};
      for (final r in (res as List)) {
        final c = int.tryParse('${r['review_count']}') ?? 0;
        if (c > 0) out[int.tryParse('${r['product_id']}') ?? -1] = Rating(double.tryParse('${r['avg_rating']}') ?? 0, c);
      }
      return out;
    } catch (_) {
      return {};
    }
  }

  static Future<List<Review>> reviews(int productId) async {
    try {
      final res = await sb.from('reviews').select('*').eq('product_id', productId).order('created_at', ascending: false).limit(20);
      return (res as List).whereType<Map>().map(Review.fromMap).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<SiteData?> siteData() async {
    try {
      final m = await sb.from('site_settings').select('data').eq('id', 1).maybeSingle();
      if (m == null || m['data'] is! Map) return null;
      return SiteData.fromMap(m['data'] as Map);
    } catch (_) {
      return null;
    }
  }

  /// Same shape the website writes: orders row + order_items rows.
  static Future<void> placeOrder({
    required String id,
    required Map<String, dynamic> customer,
    required Map<String, dynamic> payment,
    required String message,
    required List<CartItem> items,
  }) async {
    try {
      await sb.from('orders').insert({
        'id': id,
        'customer': customer,
        'payment': payment,
        'message': message,
        'status': 'Pending',
      });
    } on PostgrestException catch (e) {
      if (e.code != '23505') rethrow; // already inserted on an earlier try
    }
    await sb.from('order_items').insert(items
        .map((c) => {
              'order_id': id,
              'product_id': c.p.id,
              'seller_id': c.p.sellerId,
              'name': c.p.name,
              'price': c.p.price,
              'qty': c.qty,
              'size': c.size,
            })
        .toList());
  }

  /// Returns a payment page URL, or throws.
  static Future<String> startOnlinePayment({
    required String orderId,
    required num total,
    required Map<String, dynamic> customer,
    required String productNames,
  }) async {
    final r = await http
        .post(
          Uri.parse('${Cfg.workerUrl}/create-session'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'amount': total > 0 ? total : 10,
            'tran_id': 'ORD-$orderId',
            'cus_name': customer['name'],
            'cus_email': (customer['email'] as String?)?.isNotEmpty == true ? customer['email'] : 'customer@tabiwali.com',
            'cus_phone': customer['phone'],
            'cus_address': customer['address'],
            'product_name': productNames,
          }),
        )
        .timeout(const Duration(seconds: 25));
    final j = jsonDecode(r.body);
    if (j is Map && j['ok'] == true && j['url'] != null) return j['url'].toString();
    throw Exception(j is Map ? (j['error'] ?? 'unknown error').toString() : 'unknown error');
  }

  /// Best effort: only works for rows the logged-in user is allowed to read.
  static Future<Map<String, Map<String, String>>> orderStatuses(List<String> ids) async {
    final out = <String, Map<String, String>>{};
    if (ids.isEmpty) return out;
    try {
      final res = await sb.from('orders').select('id,status').inFilter('id', ids);
      for (final r in (res as List)) {
        out['${r['id']}'] = {'status': '${r['status'] ?? ''}'};
      }
    } catch (_) {}
    try {
      final res = await sb.from('order_items').select('order_id,track_status,courier').inFilter('order_id', ids);
      for (final r in (res as List)) {
        final m = out.putIfAbsent('${r['order_id']}', () => {});
        if ('${r['track_status'] ?? ''}'.isNotEmpty && m['track'] == null) m['track'] = '${r['track_status']}';
        if ('${r['courier'] ?? ''}'.isNotEmpty && m['courier'] == null) m['courier'] = '${r['courier']}';
      }
    } catch (_) {}
    return out;
  }

  static Future<Map<String, String>> profile() async {
    final u = sb.auth.currentUser;
    if (u == null) return {};
    try {
      final m = await sb.from('profiles').select('*').eq('id', u.id).maybeSingle();
      if (m == null) return {};
      String pick(List<String> ks) {
        for (final k in ks) {
          final v = m[k];
          if (v != null && '$v'.trim().isNotEmpty) return '$v';
        }
        return '';
      }

      return {'name': pick(['name', 'full_name']), 'phone': pick(['phone', 'mobile']), 'address': pick(['address'])};
    } catch (_) {
      return {};
    }
  }
}
