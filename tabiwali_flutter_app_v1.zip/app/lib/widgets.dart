import 'dart:convert';
import 'dart:typed_data';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import 'models.dart';
import 'state.dart';
import 'theme.dart';
import 'screens/product.dart';

final Map<String, Uint8List> _memo = {};

Uint8List? _bytes(String s) {
  final hit = _memo[s];
  if (hit != null) return hit;
  try {
    final b = base64Decode(s.substring(s.indexOf(',') + 1));
    if (_memo.length > 150) _memo.clear();
    _memo[s] = b;
    return b;
  } catch (_) {
    return null;
  }
}

Widget imgFrom(String src, {BoxFit fit = BoxFit.cover, required Widget Function() fallback}) {
  if (src.startsWith('http')) {
    return CachedNetworkImage(
      imageUrl: src,
      fit: fit,
      fadeInDuration: const Duration(milliseconds: 120),
      placeholder: (c, u) => const ColoredBox(color: Color(0xFFF1F1F1)),
      errorWidget: (c, u, e) => fallback(),
    );
  }
  if (src.startsWith('data:')) {
    final b = _bytes(src);
    if (b != null) return Image.memory(b, fit: fit, gaplessPlayback: true, errorBuilder: (c, e, s) => fallback());
  }
  return fallback();
}

Color _parseBg(String s) {
  final m = RegExp(r'#([0-9a-fA-F]{6})').firstMatch(s);
  if (m != null) return Color(int.parse('FF${m.group(1)}', radix: 16));
  return const Color(0xFFF3F3F3);
}

class ProductPic extends StatelessWidget {
  final Product p;
  final BoxFit fit;
  final String? src;
  const ProductPic(this.p, {super.key, this.fit = BoxFit.cover, this.src});

  @override
  Widget build(BuildContext context) {
    Widget fb() => Container(
          color: _parseBg(p.bg),
          alignment: Alignment.center,
          child: Text(p.emoji, style: const TextStyle(fontSize: 44)),
        );
    final s = src ?? p.cardImage;
    return s.isEmpty ? fb() : imgFrom(s, fit: fit, fallback: fb);
  }
}

class Stars extends StatelessWidget {
  final double value;
  final double size;
  const Stars(this.value, {super.key, this.size = 14});
  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      for (var i = 1; i <= 5; i++)
        Icon(value >= i ? Icons.star_rounded : (value >= i - 0.5 ? Icons.star_half_rounded : Icons.star_outline_rounded), size: size, color: starGold),
    ]);
  }
}

class RatingLine extends StatelessWidget {
  final Product p;
  const RatingLine(this.p, {super.key});
  @override
  Widget build(BuildContext context) {
    final r = context.watch<AppState>().ratings[p.id];
    if (r == null) return const SizedBox(height: 14);
    return Row(children: [
      Stars(r.avg),
      const SizedBox(width: 4),
      Text('(${r.count})', style: const TextStyle(fontSize: 12, color: linkBlue)),
    ]);
  }
}

class PriceBlock extends StatelessWidget {
  final Product p;
  final double size;
  const PriceBlock(this.p, {super.key, this.size = 18});
  @override
  Widget build(BuildContext context) {
    return Wrap(crossAxisAlignment: WrapCrossAlignment.end, spacing: 6, children: [
      Text(taka(p.price), style: TextStyle(fontSize: size, fontWeight: FontWeight.w700, color: p.hasDiscount ? priceRed : Colors.black87)),
      if (p.hasDiscount)
        Text(taka(p.oldPrice!), style: TextStyle(fontSize: size * .65, color: Colors.black45, decoration: TextDecoration.lineThrough)),
      if (p.hasDiscount) Text('-${p.discountPct}%', style: TextStyle(fontSize: size * .65, color: dealRed, fontWeight: FontWeight.w600)),
    ]);
  }
}

void openProduct(BuildContext context, Product p) {
  Navigator.of(context).push(MaterialPageRoute(builder: (_) => ProductScreen(p)));
}

class WishHeart extends StatelessWidget {
  final int id;
  const WishHeart(this.id, {super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final on = s.isWished(id);
    return InkWell(
      onTap: () => s.toggleWish(id),
      child: Container(
        padding: const EdgeInsets.all(5),
        decoration: const BoxDecoration(color: Colors.white70, shape: BoxShape.circle),
        child: Icon(on ? Icons.favorite : Icons.favorite_border, size: 18, color: on ? dealRed : Colors.black54),
      ),
    );
  }
}

/// Grid card (Amazon style)
class ProductCard extends StatelessWidget {
  final Product p;
  const ProductCard(this.p, {super.key});
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: InkWell(
        onTap: () => openProduct(context, p),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Stack(children: [
                Positioned.fill(child: ClipRRect(borderRadius: BorderRadius.circular(6), child: ProductPic(p))),
                Positioned(top: 4, right: 4, child: WishHeart(p.id)),
                if (p.hasDiscount)
                  Positioned(
                    left: 0,
                    top: 6,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: const BoxDecoration(color: dealRed, borderRadius: BorderRadius.horizontal(right: Radius.circular(4))),
                      child: Text('${p.discountPct}% ছাড়', style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w700)),
                    ),
                  ),
                if (!p.inStock)
                  Positioned.fill(
                    child: Container(
                      color: Colors.white70,
                      alignment: Alignment.center,
                      child: const Text('স্টক শেষ', style: TextStyle(fontWeight: FontWeight.w700, color: dealRed)),
                    ),
                  ),
              ]),
            ),
            const SizedBox(height: 6),
            Text(p.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, height: 1.25)),
            const SizedBox(height: 3),
            RatingLine(p),
            const SizedBox(height: 2),
            PriceBlock(p, size: 16),
            if (p.sold > 0) Text('${p.sold}+ বিক্রি হয়েছে', style: const TextStyle(fontSize: 11, color: Colors.black54)),
          ]),
        ),
      ),
    );
  }
}

/// Horizontal list tile (search results)
class ProductRow extends StatelessWidget {
  final Product p;
  const ProductRow(this.p, {super.key});
  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: InkWell(
        onTap: () => openProduct(context, p),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: 110, height: 110, child: ClipRRect(borderRadius: BorderRadius.circular(6), child: ProductPic(p))),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(p.name, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, height: 1.25)),
                const SizedBox(height: 4),
                RatingLine(p),
                const SizedBox(height: 4),
                PriceBlock(p, size: 18),
                const SizedBox(height: 4),
                Text(p.inStock ? 'ডেলিভারি: ১-৩ দিন' : 'স্টক শেষ', style: TextStyle(fontSize: 12, color: p.inStock ? okGreen : dealRed)),
              ]),
            ),
            WishHeart(p.id),
          ]),
        ),
      ),
    );
  }
}

class SectionBox extends StatelessWidget {
  final String title;
  final Widget child;
  final VoidCallback? onMore;
  const SectionBox({super.key, required this.title, required this.child, this.onMore});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
            if (onMore != null) InkWell(onTap: onMore, child: const Text('সব দেখুন', style: TextStyle(color: linkBlue, fontSize: 13))),
          ]),
        ),
        const SizedBox(height: 8),
        child,
      ]),
    );
  }
}

class Skeleton extends StatelessWidget {
  final double? w, h;
  const Skeleton({super.key, this.w, this.h});
  @override
  Widget build(BuildContext context) => Container(width: w, height: h, decoration: BoxDecoration(color: const Color(0xFFE3E3E3), borderRadius: BorderRadius.circular(6)));
}

class SkeletonGrid extends StatelessWidget {
  const SkeletonGrid({super.key});
  @override
  Widget build(BuildContext context) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 1,
      crossAxisSpacing: 1,
      childAspectRatio: .66,
      children: List.generate(
          4,
          (_) => Container(
                color: Colors.white,
                padding: const EdgeInsets.all(8),
                child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Expanded(child: Skeleton(w: double.infinity)),
                  SizedBox(height: 8),
                  Skeleton(w: 120, h: 12),
                  SizedBox(height: 6),
                  Skeleton(w: 70, h: 14),
                ]),
              )),
    );
  }
}

void snack(BuildContext c, String m, {bool error = false}) {
  ScaffoldMessenger.of(c)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(content: Text(m), backgroundColor: error ? dealRed : navy2, behavior: SnackBarBehavior.floating, duration: const Duration(seconds: 2)));
}

Future<void> openUrl(String url) async {
  try {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  } catch (_) {}
}

class CartIconButton extends StatelessWidget {
  const CartIconButton({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return IconButton(
      onPressed: () {
        Navigator.of(context).popUntil((r) => r.isFirst);
        s.setTab(3);
      },
      icon: Badge(isLabelVisible: s.cartCount > 0, label: Text('${s.cartCount}'), backgroundColor: orangeBtn, textColor: Colors.black, child: const Icon(Icons.shopping_cart_outlined)),
    );
  }
}
