import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../config.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'login.dart';
import 'orders.dart';
import 'services.dart';
import 'wishlist.dart';

class AccountScreen extends StatelessWidget {
  const AccountScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final u = s.user;
    final name = (s.profile['name'] ?? '').isNotEmpty ? s.profile['name']! : (u?.email ?? '');
    void push(Widget w) => Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));
    return Scaffold(
      appBar: AppBar(title: const Text('আমার অ্যাকাউন্ট', style: TextStyle(fontSize: 18))),
      body: ListView(children: [
        Container(
          color: navy2,
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            CircleAvatar(radius: 26, backgroundColor: searchBtn, child: Icon(u == null ? Icons.person_outline : Icons.person, color: navy, size: 28)),
            const SizedBox(width: 14),
            Expanded(
              child: u == null
                  ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text('স্বাগতম!', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 6),
                      ElevatedButton(onPressed: () => push(const LoginScreen()), style: pillButton(yellowBtn).copyWith(minimumSize: WidgetStateProperty.all(const Size(120, 38))), child: const Text('লগইন')),
                    ])
                  : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('হ্যালো, $name', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700), maxLines: 1, overflow: TextOverflow.ellipsis),
                      Text(u.email ?? '', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                    ]),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.all(10),
          child: Row(children: [
            Expanded(child: _Tile(Icons.inventory_2_outlined, 'আমার অর্ডার', () => push(const OrdersScreen()))),
            const SizedBox(width: 10),
            Expanded(child: _Tile(Icons.favorite_border, 'পছন্দের তালিকা', () => push(const WishlistScreen()))),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
          child: Row(children: [
            Expanded(child: _Tile(Icons.shopping_cart_outlined, 'কার্ট', () => s.setTab(3))),
            const SizedBox(width: 10),
            Expanded(child: _Tile(Icons.support_agent, 'সহায়তা', () => openUrl('https://wa.me/${Cfg.whatsapp}'))),
          ]),
        ),
        Container(
          color: Colors.white,
          child: Column(children: [
            _Row(Icons.storefront_outlined, 'বিক্রেতা / সার্ভিস প্রোভাইডার লগইন', () => push(const WebPageScreen(title: 'পার্টনার লগইন', url: Cfg.siteUrl))),
            _Row(Icons.public, 'ওয়েবসাইট খুলুন', () => openUrl(Cfg.siteUrl)),
            _Row(Icons.privacy_tip_outlined, 'প্রাইভেসি পলিসি', () => openUrl('${Cfg.siteUrl}/docs/privacy.pdf')),
            _Row(Icons.description_outlined, 'শর্তাবলী', () => openUrl('${Cfg.siteUrl}/docs/terms.pdf')),
            if (u != null) _Row(Icons.logout, 'লগআউট', () async {
              await Supabase.instance.client.auth.signOut();
              s.profile = {};
              if (context.mounted) snack(context, 'লগআউট হয়েছে');
            }),
          ]),
        ),
        const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('Tabiwali · Bangladesh\'s Super App · v1.0', style: TextStyle(color: Colors.black45, fontSize: 12)))),
      ]),
    );
  }
}

class _Tile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Tile(this.icon, this.label, this.onTap);
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 12),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFE0E0E0))),
          child: Row(children: [Icon(icon, color: navy), const SizedBox(width: 10), Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5)))]),
        ),
      );
}

class _Row extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  const _Row(this.icon, this.label, this.onTap);
  @override
  Widget build(BuildContext context) => ListTile(leading: Icon(icon, color: navy), title: Text(label, style: const TextStyle(fontSize: 14.5)), trailing: const Icon(Icons.chevron_right, color: Colors.black38), onTap: onTap);
}
