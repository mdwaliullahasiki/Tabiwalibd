import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'config.dart';
import 'state.dart';
import 'theme.dart';
import 'screens/home.dart';
import 'screens/categories.dart';
import 'screens/services.dart';
import 'screens/cart.dart';
import 'screens/account.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: Cfg.supabaseUrl, anonKey: Cfg.anonKey);
  final state = AppState();
  await state.init();
  runApp(ChangeNotifierProvider.value(value: state, child: const TabiwaliApp()));
}

class TabiwaliApp extends StatelessWidget {
  const TabiwaliApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Tabiwali', debugShowCheckedModeBanner: false, theme: buildTheme(), home: const Shell());
  }
}

class Shell extends StatelessWidget {
  const Shell({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return PopScope(
      canPop: s.tab == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) s.setTab(0);
      },
      child: Scaffold(
        body: IndexedStack(index: s.tab, children: const [HomeScreen(), CategoriesScreen(), ServicesScreen(), CartScreen(), AccountScreen()]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: s.tab,
          onDestinationSelected: s.setTab,
          height: 64,
          destinations: [
            const NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: navy), label: 'হোম'),
            const NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view_rounded, color: navy), label: 'ক্যাটাগরি'),
            const NavigationDestination(icon: Icon(Icons.medical_services_outlined), selectedIcon: Icon(Icons.medical_services, color: navy), label: 'সেবা'),
            NavigationDestination(
              icon: Badge(isLabelVisible: s.cartCount > 0, label: Text('${s.cartCount}'), backgroundColor: orangeBtn, textColor: Colors.black, child: const Icon(Icons.shopping_cart_outlined)),
              selectedIcon: Badge(isLabelVisible: s.cartCount > 0, label: Text('${s.cartCount}'), backgroundColor: orangeBtn, textColor: Colors.black, child: const Icon(Icons.shopping_cart, color: navy)),
              label: 'কার্ট',
            ),
            const NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person, color: navy), label: 'অ্যাকাউন্ট'),
          ],
        ),
      ),
    );
  }
}
