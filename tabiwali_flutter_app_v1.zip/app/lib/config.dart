class Cfg {
  static const supabaseUrl = 'https://ikfvvammglbxvftoasqe.supabase.co';
  static const anonKey =
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlrZnZ2YW1tZ2xieHZmdG9hc3FlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODgwOTEwOTMsImV4cCI6MjEwMzY2NzA5M30.unmjY0HKPTAc4yRT-_I8fDD8LTJa_v56TtgGAuZ6jyk';
  static const siteUrl = 'https://tabiwali.com';
  static const workerUrl = 'https://shiny-river-7418.mdwaliullahasiki2005.workers.dev';
  static const whatsapp = '8801856417790';
  static const bkash = '01856417790 (Personal)';
  static const nagad = '01856417790 (Personal)';
  static const defaultDlvIn = 60;
  static const defaultDlvOut = 120;
}
