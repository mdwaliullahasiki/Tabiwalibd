import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../api.dart';
import '../config.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'checkout.dart';
import 'search.dart';

class ProductScreen extends StatefulWidget {
  final Product p;
  const ProductScreen(this.p, {super.key});
  @override
  State<ProductScreen> createState() => _ProductScreenState();
}

class _ProductScreenState extends State<ProductScreen> {
  final _pc = PageController();
  int _img = 0;
  int _qty = 1;
  String? _size;
  List<Review> _reviews = [];
  bool _loadingDetail = true;

  Product get p => widget.p;

  @override
  void initState() {
    super.initState();
    Api.loadDetail(p).then((_) {
      if (mounted) setState(() => _loadingDetail = false);
    });
    Api.reviews(p.id).then((r) {
      if (mounted) setState(() => _reviews = r);
    });
  }

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  String _fee(num? v, int def) {
    if (v == null) return taka(def);
    return v == 0 ? 'ফ্রি' : taka(v);
  }

  void _add({bool buyNow = false}) {
    final s = context.read<AppState>();
    if (buyNow) {
      if (!p.inStock) return snack(context, 'এই পণ্যটি এখন স্টকে নেই', error: true);
      if (p.sizes.isNotEmpty && _size == null) return snack(context, 'অনুগ্রহ করে একটি সাইজ বেছে নিন', error: true);
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => CheckoutScreen(items: [CartItem(p, _qty, _size)], fromCart: false)));
      return;
    }
    final err = s.addToCart(p, qty: _qty, size: _size);
    if (err != null) {
      snack(context, err, error: true);
    } else {
      snack(context, '✅ কার্টে যোগ হয়েছে');
    }
  }

  @override
  Widget build(BuildContext context) {
    final gallery = p.gallery;
    final r = context.watch<AppState>().ratings[p.id];
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('', style: TextStyle(fontSize: 1)),
        actions: [
          IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SearchScreen())), icon: const Icon(Icons.search)),
          const CartIconButton(),
        ],
      ),
      body: ListView(children: [
        if (p.brand.isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(14, 10, 14, 0), child: Text('ব্র্যান্ড: ${p.brand}', style: const TextStyle(color: linkBlue, fontSize: 13))),
        Padding(padding: const EdgeInsets.fromLTRB(14, 6, 14, 6), child: Text(p.name, style: const TextStyle(fontSize: 17, height: 1.3))),
        if (r != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Row(children: [
              Text(r.avg.toStringAsFixed(1), style: const TextStyle(fontSize: 13)),
              const SizedBox(width: 4),
              Stars(r.avg, size: 16),
              const SizedBox(width: 6),
              Text('${r.count} রিভিউ', style: const TextStyle(color: linkBlue, fontSize: 13)),
            ]),
          ),
        const SizedBox(height: 8),
        AspectRatio(
          aspectRatio: 1,
          child: Stack(children: [
            PageView.builder(
              controller: _pc,
              itemCount: gallery.isEmpty ? 1 : gallery.length,
              onPageChanged: (i) => setState(() => _img = i),
              itemBuilder: (c, i) => Container(color: Colors.white, child: ProductPic(p, fit: BoxFit.contain, src: gallery.isEmpty ? '' : gallery[i])),
            ),
            Positioned(top: 8, right: 10, child: WishHeart(p.id)),
            if (_loadingDetail) const Positioned(bottom: 0, left: 0, right: 0, child: LinearProgressIndicator(minHeight: 2, color: orangeBtn)),
            if (gallery.length > 1)
              Positioned(
                bottom: 8,
                left: 0,
                right: 0,
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  for (var k = 0; k < gallery.length; k++)
                    Container(margin: const EdgeInsets.symmetric(horizontal: 3), width: 7, height: 7, decoration: BoxDecoration(shape: BoxShape.circle, color: k == _img ? navy : Colors.black26)),
                ]),
              ),
          ]),
        ),
        const Divider(height: 1),
        Padding(
          padding: const EdgeInsets.all(14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (p.hasDiscount) Text('-${p.discountPct}% ছাড়', style: const TextStyle(color: dealRed, fontWeight: FontWeight.w700, fontSize: 13)),
            Text(taka(p.price), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600)),
            if (p.hasDiscount) Text('আগের দাম: ${taka(p.oldPrice!)}', style: const TextStyle(color: Colors.black54, decoration: TextDecoration.lineThrough)),
            const SizedBox(height: 10),
            Text(p.inStock ? (p.stock < 10 ? 'মাত্র ${p.stock}টি বাকি — তাড়াতাড়ি করুন!' : 'স্টকে আছে') : 'স্টক শেষ', style: TextStyle(color: p.inStock ? (p.stock < 10 ? priceRed : okGreen) : dealRed, fontSize: 17, fontWeight: FontWeight.w600)),
            const SizedBox(height: 10),
            _InfoBox(children: [
              _line('🚚 ঢাকা সিটির ভিতরে', _fee(p.dlvIn, Cfg.defaultDlvIn)),
              _line('🚚 ঢাকা সিটির বাইরে', _fee(p.dlvOut, Cfg.defaultDlvOut)),
              _line('⏰ ডেলিভারি সময়', '১-৩ দিন'),
              _line('↩️ রিটার্ন', '৭ দিন'),
              _line('💵 পেমেন্ট', 'ক্যাশ অন ডেলিভারি / অনলাইন'),
            ]),
            if (p.sizes.isNotEmpty) ...[
              const SizedBox(height: 14),
              const Text('সাইজ বেছে নিন', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (final z in p.sizes) ChoiceChip(label: Text(z), selected: _size == z, selectedColor: const Color(0xFFFFE9C2), onSelected: (_) => setState(() => _size = z)),
              ]),
            ],
            const SizedBox(height: 14),
            Row(children: [
              const Text('পরিমাণ:', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(width: 10),
              _Stepper(value: _qty, onChanged: (v) => setState(() => _qty = v.clamp(1, p.stock < 1 ? 1 : p.stock))),
            ]),
            const SizedBox(height: 14),
            ElevatedButton(onPressed: _add, style: pillButton(yellowBtn), child: const Text('কার্টে যোগ করুন')),
            const SizedBox(height: 8),
            ElevatedButton(onPressed: () => _add(buyNow: true), style: pillButton(orangeBtn), child: const Text('এখনই কিনুন')),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: () => launchUrl(Uri.parse('https://wa.me/${Cfg.whatsapp}?text=${Uri.encodeComponent('আমি "${p.name}" সম্পর্কে জানতে চাই')}'), mode: LaunchMode.externalApplication),
              icon: const Icon(Icons.chat_outlined),
              label: const Text('WhatsApp-এ জিজ্ঞাসা করুন'),
              style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(44), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24))),
            ),
            if (p.description.trim().isNotEmpty) ...[
              const SizedBox(height: 20),
              const Text('পণ্যের বিবরণ', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text(p.description, style: const TextStyle(height: 1.45)),
            ],
            const SizedBox(height: 20),
            Text('কাস্টমার রিভিউ${_reviews.isEmpty ? '' : ' (${_reviews.length})'}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            if (_reviews.isEmpty) const Text('এখনো কোনো রিভিউ নেই', style: TextStyle(color: Colors.black54)),
            for (final rv in _reviews)
              Container(
                margin: const EdgeInsets.only(top: 10),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: const Color(0xFFF7F7F7), borderRadius: BorderRadius.circular(8)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Text(rv.name, style: const TextStyle(fontWeight: FontWeight.w600)),
                    const Spacer(),
                    Text(rv.date, style: const TextStyle(fontSize: 11, color: Colors.black45)),
                  ]),
                  Stars(rv.rating.toDouble(), size: 15),
                  if (rv.text.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(rv.text)),
                ]),
              ),
            const SizedBox(height: 30),
          ]),
        ),
      ]),
    );
  }

  Widget _line(String a, String b) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(children: [Expanded(child: Text(a, style: const TextStyle(fontSize: 13.5))), Text(b, style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600))]),
      );
}

class _InfoBox extends StatelessWidget {
  final List<Widget> children;
  const _InfoBox({required this.children});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(border: Border.all(color: const Color(0xFFDDDDDD)), borderRadius: BorderRadius.circular(8)),
        child: Column(children: children),
      );
}

class _Stepper extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;
  const _Stepper({required this.value, required this.onChanged});
  @override
  Widget build(BuildContext context) {
    Widget b(IconData i, VoidCallback f) => InkWell(onTap: f, child: Padding(padding: const EdgeInsets.all(8), child: Icon(i, size: 18)));
    return Container(
      decoration: BoxDecoration(color: const Color(0xFFF0F2F2), border: Border.all(color: const Color(0xFFD5D9D9)), borderRadius: BorderRadius.circular(20)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        b(Icons.remove, () => onChanged(value - 1)),
        SizedBox(width: 28, child: Text('$value', textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700))),
        b(Icons.add, () => onChanged(value + 1)),
      ]),
    );
  }
}

/// Reused by the cart screen.
class QtyStepper extends StatelessWidget {
  final int value;
  final ValueChanged<int> onChanged;
  const QtyStepper({super.key, required this.value, required this.onChanged});
  @override
  Widget build(BuildContext context) => _Stepper(value: value, onChanged: onChanged);
}
