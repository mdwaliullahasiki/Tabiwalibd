import 'dart:convert';

num _n(dynamic v, [num d = 0]) {
  if (v == null) return d;
  if (v is num) return v;
  return num.tryParse(v.toString()) ?? d;
}

String _s(dynamic v) => v == null ? '' : v.toString();

String taka(num v) {
  final neg = v < 0;
  var x = v.abs();
  final isInt = x == x.roundToDouble();
  var str = isInt ? x.round().toString() : x.toStringAsFixed(2);
  var intPart = str.split('.').first;
  final dec = str.contains('.') ? '.${str.split('.').last}' : '';
  final b = StringBuffer();
  for (var i = 0; i < intPart.length; i++) {
    final left = intPart.length - i;
    b.write(intPart[i]);
    if (left > 1 && left % 3 == 1) b.write(',');
  }
  return '${neg ? '-' : ''}৳$b$dec';
}

class Product {
  final int id;
  final String? sellerId;
  final String name;
  final String cat;
  final num price;
  final num? oldPrice;
  final String emoji;
  final String bg;
  final String tag;
  final int stock;
  final int sold;
  final List<String> sizes;
  final String brand;
  final String thumbUrl;
  final String thumbB64;
  // detail-only
  String description;
  String imageB64;
  List<String> images;
  num? dlvIn;
  num? dlvOut;
  bool detailLoaded = false;

  Product({
    required this.id,
    this.sellerId,
    required this.name,
    this.cat = '',
    required this.price,
    this.oldPrice,
    this.emoji = '🛍️',
    this.bg = '',
    this.tag = '',
    this.stock = 99,
    this.sold = 0,
    this.sizes = const [],
    this.brand = '',
    this.thumbUrl = '',
    this.thumbB64 = '',
    this.description = '',
    this.imageB64 = '',
    this.images = const [],
    this.dlvIn,
    this.dlvOut,
  });

  factory Product.fromMap(Map m) {
    List<String> sizes = [];
    final sz = m['sizes'];
    if (sz is List) sizes = sz.map((e) => e.toString()).toList();
    List<String> imgs = [];
    final im = m['images'];
    if (im is List) imgs = im.whereType<String>().toList();
    final old = m['old_price'];
    return Product(
      id: _n(m['id']).toInt(),
      sellerId: m['seller_id']?.toString(),
      name: _s(m['name']),
      cat: _s(m['cat']),
      price: _n(m['price']),
      oldPrice: old == null ? null : _n(old),
      emoji: _s(m['emoji']).isEmpty ? '🛍️' : _s(m['emoji']),
      bg: _s(m['bg']),
      tag: _s(m['tag']),
      stock: m['stock'] == null ? 99 : _n(m['stock']).toInt(),
      sold: _n(m['sold']).toInt(),
      sizes: sizes,
      brand: _s(m['brand']),
      thumbUrl: _s(m['thumb_url']),
      thumbB64: _s(m['thumb_b64']),
      description: _s(m['description']),
      imageB64: _s(m['image_b64']),
      images: imgs,
      dlvIn: m['delivery_dhaka'] == null || _s(m['delivery_dhaka']).isEmpty ? null : _n(m['delivery_dhaka']),
      dlvOut: m['delivery_outside'] == null || _s(m['delivery_outside']).isEmpty ? null : _n(m['delivery_outside']),
    );
  }

  /// Small map for local storage (cart / wishlist cache).
  Map<String, dynamic> toLocal() => {
        'id': id,
        'seller_id': sellerId,
        'name': name,
        'cat': cat,
        'price': price,
        'old_price': oldPrice,
        'emoji': emoji,
        'bg': bg,
        'tag': tag,
        'stock': stock,
        'sold': sold,
        'sizes': sizes,
        'brand': brand,
        'thumb_url': thumbUrl,
        'thumb_b64': thumbB64.length < 60000 ? thumbB64 : '',
      };

  bool get hasDiscount => oldPrice != null && oldPrice! > price;
  int get discountPct => hasDiscount ? (((oldPrice! - price) / oldPrice!) * 100).round() : 0;
  bool get inStock => stock > 0;

  /// All image sources, best first.
  List<String> get gallery {
    final out = <String>[];
    void add(String s) {
      if (s.isEmpty) return;
      if (!(s.startsWith('http') || s.startsWith('data:'))) return;
      if (!out.contains(s)) out.add(s);
    }

    add(imageB64);
    for (final i in images) {
      add(i);
    }
    if (out.isEmpty) {
      add(thumbUrl);
      add(thumbB64);
    }
    return out;
  }

  String get cardImage {
    for (final s in [thumbUrl, thumbB64, imageB64, ...images]) {
      if (s.startsWith('http') || s.startsWith('data:')) return s;
    }
    return '';
  }
}

class CartItem {
  final Product p;
  int qty;
  final String? size;
  CartItem(this.p, this.qty, this.size);
  String get key => '${p.id}|${size ?? ''}';
  num get line => p.price * qty;

  Map<String, dynamic> toJson() => {'p': p.toLocal(), 'q': qty, 's': size};
  factory CartItem.fromJson(Map m) => CartItem(Product.fromMap(Map.from(m['p'])), _n(m['q'], 1).toInt(), m['s']?.toString());
}

class Rating {
  final double avg;
  final int count;
  const Rating(this.avg, this.count);
}

class Review {
  final String name;
  final int rating;
  final String text;
  final String date;
  Review(this.name, this.rating, this.text, this.date);
  factory Review.fromMap(Map m) => Review(
        _s(m['customer_name']).isEmpty ? 'Customer' : _s(m['customer_name']),
        _n(m['rating']).toInt(),
        _s(m['comment']),
        _s(m['created_at']).length >= 10 ? _s(m['created_at']).substring(0, 10) : '',
      );
}

class CatNode {
  final String id;
  final String name;
  final List<CatNode> children;
  CatNode(this.id, this.name, this.children);

  factory CatNode.fromMap(Map m) => CatNode(
        _s(m['id']),
        _s(m['name']),
        (m['children'] is List) ? (m['children'] as List).whereType<Map>().map(CatNode.fromMap).toList() : [],
      );

  static bool _isEmojiToken(String t) => t.isNotEmpty && !RegExp(r'[\u0980-\u09FFA-Za-z0-9]').hasMatch(t);

  String get icon {
    final parts = name.split(' ');
    return parts.length > 1 && _isEmojiToken(parts.first) ? parts.first : '🛍️';
  }

  String get label {
    final parts = name.split(' ');
    return parts.length > 1 && _isEmojiToken(parts.first) ? parts.sublist(1).join(' ') : name;
  }

  /// Product `cat` column holds the category NAME, so we filter by names of the whole subtree.
  List<String> subtreeNames() {
    final out = <String>[name];
    for (final c in children) {
      out.addAll(c.subtreeNames());
    }
    return out;
  }
}

class HeroAd {
  final String img;
  final String link;
  HeroAd(this.img, this.link);
}

class SiteData {
  final List<HeroAd> heroAds;
  final int heroIntervalMs;
  final Map<String, String> catImages;
  final List<CatNode>? catTree;
  const SiteData({this.heroAds = const [], this.heroIntervalMs = 4000, this.catImages = const {}, this.catTree});

  factory SiteData.fromMap(Map d) {
    final ads = <HeroAd>[];
    if (d['heroAds'] is List) {
      for (final a in d['heroAds']) {
        if (a is Map && _s(a['img']).isNotEmpty) ads.add(HeroAd(_s(a['img']), _s(a['link'])));
      }
    }
    final imgs = <String, String>{};
    if (d['catImages'] is Map) {
      (d['catImages'] as Map).forEach((k, v) {
        if (v is String && v.isNotEmpty) imgs[k.toString()] = v;
      });
    }
    List<CatNode>? tree;
    if (d['catTree'] is List && (d['catTree'] as List).isNotEmpty) {
      tree = (d['catTree'] as List).whereType<Map>().map(CatNode.fromMap).toList();
    }
    var ms = 4000;
    if (d['heroAdsSettings'] is Map) {
      final i = _n((d['heroAdsSettings'] as Map)['interval'], 4000).toInt();
      if (i >= 1500) ms = i;
    }
    return SiteData(heroAds: ads, heroIntervalMs: ms, catImages: imgs, catTree: tree);
  }
}

class OrderLine {
  final int productId;
  final String name;
  final num price;
  final int qty;
  final String? size;
  OrderLine(this.productId, this.name, this.price, this.qty, this.size);
  Map<String, dynamic> toJson() => {'id': productId, 'n': name, 'p': price, 'q': qty, 's': size};
  factory OrderLine.fromJson(Map m) => OrderLine(_n(m['id']).toInt(), _s(m['n']), _n(m['p']), _n(m['q'], 1).toInt(), m['s']?.toString());
}

class AppOrder {
  final String id;
  final String createdAt;
  final num total;
  String status;
  String track;
  String courier;
  final String payment;
  final String name;
  final String phone;
  final String address;
  final List<OrderLine> items;
  AppOrder({
    required this.id,
    required this.createdAt,
    required this.total,
    this.status = 'Pending',
    this.track = '',
    this.courier = '',
    required this.payment,
    required this.name,
    required this.phone,
    required this.address,
    required this.items,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'at': createdAt,
        'total': total,
        'status': status,
        'track': track,
        'courier': courier,
        'payment': payment,
        'name': name,
        'phone': phone,
        'address': address,
        'items': items.map((e) => e.toJson()).toList(),
      };

  factory AppOrder.fromJson(Map m) => AppOrder(
        id: _s(m['id']),
        createdAt: _s(m['at']),
        total: _n(m['total']),
        status: _s(m['status']).isEmpty ? 'Pending' : _s(m['status']),
        track: _s(m['track']),
        courier: _s(m['courier']),
        payment: _s(m['payment']),
        name: _s(m['name']),
        phone: _s(m['phone']),
        address: _s(m['address']),
        items: (m['items'] is List) ? (m['items'] as List).whereType<Map>().map(OrderLine.fromJson).toList() : [],
      );
}

String encodeJson(Object o) => jsonEncode(o);
