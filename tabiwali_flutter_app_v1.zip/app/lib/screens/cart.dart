import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'checkout.dart';
import 'product.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('আমার কার্ট', style: TextStyle(fontSize: 18))),
      body: s.cart.isEmpty
          ? Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.shopping_cart_outlined, size: 70, color: Colors.black26),
                const SizedBox(height: 10),
                const Text('আপনার কার্ট খালি', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                const SizedBox(height: 14),
                SizedBox(width: 220, child: ElevatedButton(onPressed: () => s.setTab(0), style: pillButton(yellowBtn), child: const Text('কেনাকাটা চালিয়ে যান'))),
              ]),
            )
          : Column(children: [
              Expanded(
                child: ListView(children: [
                  Container(
                    color: Colors.white,
                    padding: const EdgeInsets.all(14),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text.rich(TextSpan(children: [
                        TextSpan(text: 'সাবটোটাল (${s.cartCount} আইটেম): ', style: const TextStyle(fontSize: 16)),
                        TextSpan(text: taka(s.cartTotal), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                      ])),
                      const SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CheckoutScreen(items: List.of(s.cart), fromCart: true))),
                        style: pillButton(yellowBtn),
                        child: Text('অর্ডার করুন (${s.cartCount} আইটেম)'),
                      ),
                    ]),
                  ),
                  const SizedBox(height: 8),
                  for (final c in List.of(s.cart)) _CartTile(c),
                  const SizedBox(height: 20),
                ]),
              ),
            ]),
    );
  }
}

class _CartTile extends StatelessWidget {
  final CartItem c;
  const _CartTile(this.c);
  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(bottom: 1),
      padding: const EdgeInsets.all(12),
      child: Column(children: [
        InkWell(
          onTap: () => openProduct(context, c.p),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            SizedBox(width: 96, height: 96, child: ClipRRect(borderRadius: BorderRadius.circular(6), child: ProductPic(c.p))),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(c.p.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14)),
                const SizedBox(height: 4),
                Text(taka(c.p.price), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                if (c.size != null) Text('সাইজ: ${c.size}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                Text(c.p.inStock ? 'স্টকে আছে' : 'স্টক শেষ', style: TextStyle(fontSize: 12, color: c.p.inStock ? okGreen : dealRed)),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 8),
        Row(children: [
          QtyStepper(value: c.qty, onChanged: (v) => s.setQty(c, v)),
          const SizedBox(width: 10),
          OutlinedButton(
            onPressed: () => s.removeFromCart(c),
            style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)), minimumSize: const Size(0, 36)),
            child: const Text('মুছুন', style: TextStyle(fontSize: 13)),
          ),
          const Spacer(),
          Text(taka(c.line), style: const TextStyle(fontWeight: FontWeight.w600)),
        ]),
      ]),
    );
  }
}
