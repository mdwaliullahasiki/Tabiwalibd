import 'package:flutter/material.dart';
import '../api.dart';
import '../models.dart';
import '../theme.dart';
import '../widgets.dart';
import 'search.dart';

class CategoryProductsScreen extends StatefulWidget {
  final CatNode node;
  const CategoryProductsScreen({super.key, required this.node});
  @override
  State<CategoryProductsScreen> createState() => _CategoryProductsScreenState();
}

class _CategoryProductsScreenState extends State<CategoryProductsScreen> {
  final _sc = ScrollController();
  final List<Product> _items = [];
  late CatNode _cur = widget.node;
  String _sort = 'new';
  int _page = 0;
  bool _loading = false, _more = true, _error = false;

  @override
  void initState() {
    super.initState();
    _sc.addListener(() {
      if (_sc.position.pixels > _sc.position.maxScrollExtent - 600) _load();
    });
    _load(reset: true);
  }

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  Future<void> _load({bool reset = false}) async {
    if (_loading || (!_more && !reset)) return;
    setState(() {
      _loading = true;
      _error = false;
      if (reset) {
        _page = 0;
        _more = true;
        _items.clear();
      }
    });
    try {
      final r = await Api.products(cats: _cur.subtreeNames(), page: _page, size: 20, sort: _sort);
      if (!mounted) return;
      setState(() {
        _items.addAll(r);
        _more = r.length == 20;
        _page++;
      });
    } catch (_) {
      if (mounted) setState(() => _error = true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _pickSort() {
    showModalBottomSheet(
      context: context,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final e in const {'new': 'নতুন আগে', 'popular': 'জনপ্রিয়', 'low': 'দাম: কম থেকে বেশি', 'high': 'দাম: বেশি থেকে কম'}.entries)
            ListTile(
              title: Text(e.value),
              trailing: _sort == e.key ? const Icon(Icons.check, color: okGreen) : null,
              onTap: () {
                Navigator.pop(c);
                setState(() => _sort = e.key);
                _load(reset: true);
              },
            ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final subs = widget.node.children;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.node.label, style: const TextStyle(fontSize: 17)),
        actions: [
          IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SearchScreen())), icon: const Icon(Icons.search)),
          const CartIconButton(),
        ],
      ),
      body: Column(children: [
        if (subs.isNotEmpty)
          Container(
            color: Colors.white,
            height: 46,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), children: [
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(
                  label: const Text('সব'),
                  selected: _cur == widget.node,
                  onSelected: (_) {
                    _cur = widget.node;
                    _load(reset: true);
                  },
                ),
              ),
              for (final sub in subs)
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(
                    label: Text(sub.name, style: const TextStyle(fontSize: 12.5)),
                    selected: _cur == sub,
                    onSelected: (_) {
                      _cur = sub;
                      _load(reset: true);
                    },
                  ),
                ),
            ]),
          ),
        Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
          child: Row(children: [
            const Spacer(),
            TextButton.icon(onPressed: _pickSort, icon: const Icon(Icons.sort, size: 18), label: const Text('সর্ট')),
          ]),
        ),
        Expanded(
          child: _items.isEmpty && !_loading
              ? Center(child: Text(_error ? 'ইন্টারনেট সংযোগ পরীক্ষা করুন' : 'এই ক্যাটাগরিতে এখনো কোনো পণ্য নেই', style: const TextStyle(color: Colors.black54)))
              : GridView.builder(
                  controller: _sc,
                  itemCount: _items.length + (_loading ? 2 : 0),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 1, crossAxisSpacing: 1, childAspectRatio: .62),
                  itemBuilder: (c, i) => i < _items.length ? ProductCard(_items[i]) : Container(color: Colors.white, padding: const EdgeInsets.all(8), child: const Skeleton()),
                ),
        ),
      ]),
    );
  }
}
