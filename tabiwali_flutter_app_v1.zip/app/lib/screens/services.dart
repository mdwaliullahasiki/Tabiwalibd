import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../config.dart';
import '../theme.dart';

class _Web extends StatefulWidget {
  final String url;
  const _Web({required this.url});
  @override
  State<_Web> createState() => _WebState();
}

class _WebState extends State<_Web> with AutomaticKeepAliveClientMixin {
  late final WebViewController c;
  bool loading = true;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    c = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) => setState(() => loading = true),
        onPageFinished: (_) => setState(() => loading = false),
        onNavigationRequest: (r) {
          final u = Uri.tryParse(r.url);
          if (u != null && (u.scheme == 'http' || u.scheme == 'https' || u.scheme == 'about' || u.scheme == 'data' || u.scheme == 'blob')) {
            return NavigationDecision.navigate;
          }
          if (u != null) launchUrl(u, mode: LaunchMode.externalApplication).catchError((_) => false);
          return NavigationDecision.prevent;
        },
      ))
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Stack(children: [
      WebViewWidget(controller: c),
      if (loading) const Positioned(top: 0, left: 0, right: 0, child: LinearProgressIndicator(minHeight: 3, color: orangeBtn, backgroundColor: Colors.white)),
    ]);
  }
}

/// Bottom-nav "সেবা" tab: the site's service pages inside the app.
class ServicesScreen extends StatefulWidget {
  const ServicesScreen({super.key});
  @override
  State<ServicesScreen> createState() => _ServicesScreenState();
}

class _ServicesScreenState extends State<ServicesScreen> {
  int _i = 0;
  static const _tabs = [
    ['🛠️ সেবা ও বুকিং', '/services'],
    ['🩺 ডাক্তার', '/doctors'],
    ['📝 ব্লগ', '/blog'],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('সেবা ও বুকিং', style: TextStyle(fontSize: 18))),
      body: Column(children: [
        Container(
          color: Colors.white,
          height: 46,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6), children: [
            for (var k = 0; k < _tabs.length; k++)
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(label: Text(_tabs[k][0], style: const TextStyle(fontSize: 12.5)), selected: _i == k, onSelected: (_) => setState(() => _i = k)),
              ),
          ]),
        ),
        Expanded(child: IndexedStack(index: _i, children: [for (final t in _tabs) _Web(url: '${Cfg.siteUrl}${t[1]}')])),
      ]),
    );
  }
}

/// Full page for shortcuts / policy links.
class WebPageScreen extends StatelessWidget {
  final String title;
  final String url;
  const WebPageScreen({super.key, required this.title, required this.url});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: Text(title, style: const TextStyle(fontSize: 17))), body: _Web(url: url));
  }
}
