import 'package:flutter/material.dart';

const navy = Color(0xFF0B1B3A);
const navy2 = Color(0xFF1B3358);
const navyDeep = Color(0xFF131A22);
const yellowBtn = Color(0xFFFFD814);
const orangeBtn = Color(0xFFFFA41C);
const searchBtn = Color(0xFFFEBD69);
const bgGrey = Color(0xFFEAEDED);
const priceRed = Color(0xFFB12704);
const dealRed = Color(0xFFCC0C39);
const okGreen = Color(0xFF007600);
const linkBlue = Color(0xFF007185);
const starGold = Color(0xFFFFA41C);

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: navy, primary: navy, secondary: orangeBtn);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: bgGrey,
    appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white, elevation: 0),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: Colors.white,
      indicatorColor: const Color(0xFFFFE9C2),
      labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFBBBBBB))),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFFBBBBBB))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: orangeBtn, width: 2)),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
    ),
  );
}

ButtonStyle pillButton(Color bg, {Color fg = Colors.black}) => ElevatedButton.styleFrom(
      backgroundColor: bg,
      foregroundColor: fg,
      elevation: 0,
      minimumSize: const Size.fromHeight(46),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
    );
