import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../api.dart';
import '../config.dart';
import '../models.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets.dart';
import 'category_products.dart';
import 'search.dart';
import 'services.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _sc = ScrollController();
  final List<Product> _items = [];
  List<Product> _deals = [];
  int _page = 0;
  bool _loading = false, _more = true, _error = false;

  @override
  void initState() {
    super.initState();
    _sc.addListener(() {
      if (_sc.position.pixels > _sc.position.maxScrollExtent - 700) _load();
    });
    _load(reset: true);
    _loadDeals();
  }

  @override
  void dispose() {
    _sc.dispose();
    super.dispose();
  }

  Future<void> _loadDeals() async {
    try {
      final d = await Api.products(dealsOnly: true, size: 12);
      if (mounted) setState(() => _deals = d.where((p) => p.hasDiscount).toList());
    } catch (_) {}
  }

  Future<void> _load({bool reset = false}) async {
    if (_loading || (!_more && !reset)) return;
    setState(() {
      _loading = true;
      _error = false;
      if (reset) {
        _page = 0;
        _more = true;
      }
    });
    try {
      final res = await Api.products(page: _page, size: 20);
      if (!mounted) return;
      setState(() {
        if (reset) _items.clear();
        _items.addAll(res);
        _more = res.length == 20;
        _page++;
      });
    } catch (_) {
      if (mounted) setState(() => _error = true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _refresh() async {
    final s = context.read<AppState>();
    await Future.wait([_load(reset: true), _loadDeals(), s.refreshSite(), s.refreshRatings()]);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return RefreshIndicator(
      onRefresh: _refresh,
      edgeOffset: 70,
      child: CustomScrollView(controller: _sc, physics: const AlwaysScrollableScrollPhysics(), slivers: [
        SliverAppBar(
          pinned: true,
          toolbarHeight: 62,
          backgroundColor: navy,
          titleSpacing: 10,
          title: Row(children: [
            ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.asset('assets/logo.png', width: 38, height: 38)),
            const SizedBox(width: 10),
            Expanded(
              child: GestureDetector(
                onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SearchScreen())),
                child: Container(
                  height: 42,
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)),
                  child: Row(children: [
                    const SizedBox(width: 12),
                    const Expanded(child: Text('Tabiwali-তে খুঁজুন', style: TextStyle(color: Colors.black45, fontSize: 14))),
                    Container(
                      width: 46,
                      height: 42,
                      decoration: const BoxDecoration(color: searchBtn, borderRadius: BorderRadius.horizontal(right: Radius.circular(8))),
                      child: const Icon(Icons.search, color: Colors.black87),
                    ),
                  ]),
                ),
              ),
            ),
          ]),
        ),
        SliverToBoxAdapter(
          child: Container(
            color: navy2,
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            child: const Row(children: [
              Icon(Icons.location_on_outlined, color: Colors.white, size: 18),
              SizedBox(width: 6),
              Expanded(child: Text('সারা বাংলাদেশে ডেলিভারি · ক্যাশ অন ডেলিভারি', style: TextStyle(color: Colors.white, fontSize: 12.5))),
            ]),
          ),
        ),
        SliverToBoxAdapter(child: _CategoryStrip(tree: s.tree, images: s.site.catImages)),
        SliverToBoxAdapter(child: HeroCarousel(ads: s.site.heroAds, intervalMs: s.site.heroIntervalMs)),
        SliverToBoxAdapter(child: _ServiceShortcuts()),
        if (_deals.isNotEmpty)
          SliverToBoxAdapter(
            child: SectionBox(
              title: '🔥 আজকের ডিল',
              child: SizedBox(
                height: 232,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  itemCount: _deals.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (c, i) => SizedBox(width: 140, child: DecoratedBox(decoration: BoxDecoration(border: Border.all(color: const Color(0xFFEEEEEE))), child: ProductCard(_deals[i]))),
                ),
              ),
            ),
          ),
        SliverToBoxAdapter(
          child: Container(
            color: Colors.white,
            margin: const EdgeInsets.only(top: 8),
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
            child: const Text('আপনার জন্য সেরা পণ্য', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          ),
        ),
        if (_items.isEmpty && _loading) const SliverToBoxAdapter(child: SkeletonGrid()),
        SliverGrid(
          delegate: SliverChildBuilderDelegate((c, i) => ProductCard(_items[i]), childCount: _items.length),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 1, crossAxisSpacing: 1, childAspectRatio: .62),
        ),
        SliverToBoxAdapter(
          child: Container(
            color: Colors.white,
            padding: const EdgeInsets.all(20),
            alignment: Alignment.center,
            child: _error
                ? Column(children: [
                    const Text('ইন্টারনেট সংযোগ পরীক্ষা করুন', style: TextStyle(color: dealRed)),
                    TextButton(onPressed: () => _load(reset: _items.isEmpty), child: const Text('আবার চেষ্টা করুন')),
                  ])
                : _loading
                    ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.5))
                    : (!_more && _items.isNotEmpty ? const Text('সব পণ্য দেখা হয়ে গেছে', style: TextStyle(color: Colors.black45)) : const SizedBox.shrink()),
          ),
        ),
      ]),
    );
  }
}

class _CategoryStrip extends StatelessWidget {
  final List<CatNode> tree;
  final Map<String, String> images;
  const _CategoryStrip({required this.tree, required this.images});
  @override
  Widget build(BuildContext context) {
    if (tree.isEmpty) return const SizedBox.shrink();
    return Container(
      color: Colors.white,
      height: 96,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        itemCount: tree.length,
        itemBuilder: (c, i) {
          final n = tree[i];
          final img = images[n.id];
          return InkWell(
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CategoryProductsScreen(node: n))),
            child: SizedBox(
              width: 72,
              child: Column(children: [
                Container(
                  width: 52,
                  height: 52,
                  clipBehavior: Clip.antiAlias,
                  decoration: const BoxDecoration(color: Color(0xFFF1F4F8), shape: BoxShape.circle),
                  alignment: Alignment.center,
                  child: img != null
                      ? SizedBox.expand(child: imgFrom(img, fallback: () => Text(n.icon, style: const TextStyle(fontSize: 24))))
                      : Text(n.icon, style: const TextStyle(fontSize: 24)),
                ),
                const SizedBox(height: 4),
                Text(n.label, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, height: 1.15)),
              ]),
            ),
          );
        },
      ),
    );
  }
}

class HeroCarousel extends StatefulWidget {
  final List<HeroAd> ads;
  final int intervalMs;
  const HeroCarousel({super.key, required this.ads, required this.intervalMs});
  @override
  State<HeroCarousel> createState() => _HeroCarouselState();
}

class _HeroCarouselState extends State<HeroCarousel> {
  final _pc = PageController();
  Timer? _t;
  int _i = 0;

  @override
  void initState() {
    super.initState();
    _t = Timer.periodic(Duration(milliseconds: widget.intervalMs), (_) {
      if (!mounted || widget.ads.length < 2 || !_pc.hasClients) return;
      _pc.animateToPage((_i + 1) % widget.ads.length, duration: const Duration(milliseconds: 450), curve: Curves.easeOut);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    _pc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final ads = widget.ads;
    if (ads.isEmpty) {
      return Container(
        margin: const EdgeInsets.all(10),
        child: AspectRatio(aspectRatio: 16 / 5, child: ClipRRect(borderRadius: BorderRadius.circular(12), child: const Skeleton())),
      );
    }
    return Container(
      color: bgGrey,
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
      child: AspectRatio(
        aspectRatio: 16 / 5,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: Stack(children: [
            PageView.builder(
              controller: _pc,
              itemCount: ads.length,
              onPageChanged: (v) => setState(() => _i = v),
              itemBuilder: (c, i) => GestureDetector(
                onTap: () {
                  final l = ads[i].link;
                  if (l.startsWith('http')) openUrl(l);
                },
                child: imgFrom(ads[i].img, fallback: () => const ColoredBox(color: navy2)),
              ),
            ),
            if (ads.length > 1)
              Positioned(
                bottom: 6,
                left: 0,
                right: 0,
                child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  for (var k = 0; k < ads.length; k++)
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 2.5),
                      width: k == _i ? 16 : 6,
                      height: 6,
                      decoration: BoxDecoration(color: k == _i ? Colors.white : Colors.white54, borderRadius: BorderRadius.circular(3)),
                    ),
                ]),
              ),
          ]),
        ),
      ),
    );
  }
}

class _ServiceShortcuts extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = const [
      ['🩺', 'অনলাইন ডাক্তার', '/doctors'],
      ['🛠️', 'সেবা ও বুকিং', '/services'],
      ['📝', 'ব্লগ', '/blog'],
      ['🌐', 'পুরো সাইট', '/'],
    ];
    return Container(
      color: Colors.white,
      margin: const EdgeInsets.only(top: 4),
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 6),
      child: Row(children: [
        for (final it in items)
          Expanded(
            child: InkWell(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => WebPageScreen(title: it[1], url: '${Cfg.siteUrl}${it[2]}'))),
              child: Column(children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(color: const Color(0xFFFFF4DD), borderRadius: BorderRadius.circular(14)),
                  alignment: Alignment.center,
                  child: Text(it[0], style: const TextStyle(fontSize: 24)),
                ),
                const SizedBox(height: 4),
                Text(it[1], textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5)),
              ]),
            ),
          ),
      ]),
    );
  }
}
