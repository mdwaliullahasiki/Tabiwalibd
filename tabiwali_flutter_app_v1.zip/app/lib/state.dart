import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'api.dart';
import 'models.dart';

class AppState extends ChangeNotifier {
  late SharedPreferences prefs;
  List<CartItem> cart = [];
  Set<int> wish = {};
  List<AppOrder> orders = [];
  List<String> history = [];
  SiteData site = const SiteData();
  Map<int, Rating> ratings = {};
  List<CatNode> _bundledTree = [];
  int tab = 0;
  Map<String, String> profile = {};

  User? get user => Supabase.instance.client.auth.currentUser;

  List<CatNode> get tree => site.catTree ?? _bundledTree;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    try {
      final raw = await rootBundle.loadString('assets/cattree.json');
      _bundledTree = (jsonDecode(raw) as List).whereType<Map>().map(CatNode.fromMap).toList();
    } catch (_) {}
    try {
      final c = prefs.getString('cart');
      if (c != null) cart = (jsonDecode(c) as List).whereType<Map>().map(CartItem.fromJson).toList();
    } catch (_) {}
    try {
      final w = prefs.getString('wish');
      if (w != null) wish = (jsonDecode(w) as List).map((e) => int.parse('$e')).toSet();
    } catch (_) {}
    try {
      final o = prefs.getString('orders');
      if (o != null) orders = (jsonDecode(o) as List).whereType<Map>().map(AppOrder.fromJson).toList();
    } catch (_) {}
    history = prefs.getStringList('history') ?? [];
    try {
      final s = prefs.getString('site');
      if (s != null) site = SiteData.fromMap(jsonDecode(s) as Map);
    } catch (_) {}
    Supabase.instance.client.auth.onAuthStateChange.listen((_) {
      loadProfile();
      notifyListeners();
    });
    unawaited(refreshSite());
    unawaited(refreshRatings());
    unawaited(loadProfile());
  }

  Future<void> refreshSite() async {
    final s = await Api.siteData();
    if (s != null) {
      site = s;
      notifyListeners();
    }
  }

  Future<void> refreshRatings() async {
    ratings = await Api.ratings();
    notifyListeners();
  }

  Future<void> loadProfile() async {
    profile = await Api.profile();
    notifyListeners();
  }

  void setTab(int i) {
    tab = i;
    notifyListeners();
  }

  // ---- cart ----
  int get cartCount => cart.fold(0, (a, c) => a + c.qty);
  num get cartTotal => cart.fold<num>(0, (a, c) => a + c.line);

  void _saveCart() => prefs.setString('cart', jsonEncode(cart.map((e) => e.toJson()).toList()));

  /// returns an error message or null
  String? addToCart(Product p, {int qty = 1, String? size}) {
    if (!p.inStock) return 'এই পণ্যটি এখন স্টকে নেই';
    if (p.sizes.isNotEmpty && (size == null || size.isEmpty)) return 'অনুগ্রহ করে একটি সাইজ বেছে নিন';
    final key = '${p.id}|${size ?? ''}';
    final i = cart.indexWhere((c) => c.key == key);
    if (i >= 0) {
      cart[i].qty = (cart[i].qty + qty).clamp(1, p.stock);
    } else {
      cart.add(CartItem(p, qty.clamp(1, p.stock), size));
    }
    _saveCart();
    notifyListeners();
    return null;
  }

  void setQty(CartItem c, int q) {
    if (q <= 0) {
      cart.remove(c);
    } else {
      c.qty = q.clamp(1, c.p.stock);
    }
    _saveCart();
    notifyListeners();
  }

  void removeFromCart(CartItem c) {
    cart.remove(c);
    _saveCart();
    notifyListeners();
  }

  void clearCart() {
    cart.clear();
    _saveCart();
    notifyListeners();
  }

  // ---- wishlist ----
  bool isWished(int id) => wish.contains(id);
  void toggleWish(int id) {
    wish.contains(id) ? wish.remove(id) : wish.add(id);
    prefs.setString('wish', jsonEncode(wish.toList()));
    notifyListeners();
  }

  // ---- orders ----
  void addOrder(AppOrder o) {
    orders.insert(0, o);
    prefs.setString('orders', jsonEncode(orders.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  Future<void> refreshOrders() async {
    final ids = orders.take(40).map((o) => o.id).toList();
    final st = await Api.orderStatuses(ids);
    var changed = false;
    for (final o in orders) {
      final s = st[o.id];
      if (s == null) continue;
      if ((s['status'] ?? '').isNotEmpty && s['status'] != o.status) {
        o.status = s['status']!;
        changed = true;
      }
      if (s['track'] != null && s['track'] != o.track) {
        o.track = s['track']!;
        changed = true;
      }
      if (s['courier'] != null && s['courier'] != o.courier) {
        o.courier = s['courier']!;
        changed = true;
      }
    }
    if (changed) {
      prefs.setString('orders', jsonEncode(orders.map((e) => e.toJson()).toList()));
      notifyListeners();
    }
  }

  // ---- search history ----
  void addHistory(String q) {
    q = q.trim();
    if (q.isEmpty) return;
    history.remove(q);
    history.insert(0, q);
    if (history.length > 10) history = history.sublist(0, 10);
    prefs.setStringList('history', history);
    notifyListeners();
  }

  void clearHistory() {
    history = [];
    prefs.setStringList('history', history);
    notifyListeners();
  }
}
